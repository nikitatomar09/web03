var localStorage = ('localStorage' in window);
function saveData(key, value) {
    if(localStorage) {
        localStorage.setItem(key,value);
    }
}
function loadData(key) {
    if(localStorage) {
        if(key in localStorage) {
            return localStorage.getItem(key);
        }
    }
}
function setData() {
    let username= document.getElementById("username").value;
    let pass= document.getElementById("pass").value;
    let con_pass= document.getElementById("con_pass").value;
    console.log(username+" hkghbi ");
    saveData("username",username);
    saveData("pass",pass);
    saveData("con_pass",con_pass);
}
function set() {
    setData();

}
function onLoad() {
    loadData("username") && (document.getElementById("username").value = loadData("username"));
    loadData("pass") && (document.getElementById("pass").value = loadData("pass"));
    loadData("con_pass") && (document.getElementById("con_pass").value = loadData("con_pass"));

setData();
}

