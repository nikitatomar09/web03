let form = document.forms.register;
function validate() {
    console.log("validate");
    form.username.setCustomValidity("");
    form.pass.setCustomValidity("");
    form.con_pass.setCustomValidity("");


    if(form.username.value.length < 6) {
        form.username.setCustomValidity("Can't be less than 6.");
    }
    if(form.pass.value.length < 8) {
        form.pass.setCustomValidity("Can't be less than 8.");
    }
    if(form.con_pass.value != form.pass.value) {
        form.con_pass.setCustomValidity("Passwords do not match");
    }
}
form.addEventListener("input",validate);





